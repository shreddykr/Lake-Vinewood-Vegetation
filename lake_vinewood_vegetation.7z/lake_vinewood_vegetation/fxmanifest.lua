fx_version 'bodacious'

game 'gta5'

description 'Lake Vinewood Added Vegetation w/optional Heli Pads'
author 'shreddykr'
version '1.0'


this_is_a_map 'yes'

escrow_ignore {
    "optional/**/*",
    "required/**/*",
}

dependencies {
    'mbmaps',
    'mbv_vol1',
}